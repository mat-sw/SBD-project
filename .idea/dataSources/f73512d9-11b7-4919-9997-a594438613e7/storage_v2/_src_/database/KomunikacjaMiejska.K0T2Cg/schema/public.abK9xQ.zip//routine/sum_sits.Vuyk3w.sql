create function sum_sits(id_mod integer) returns integer
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT liczba_miejsc_siedzacych + liczba_miejsc_stojacych FROM modele_pojazdow WHERE id_modelu = id_mod);
END;
$$;

alter function sum_sits(integer) owner to postgres;

