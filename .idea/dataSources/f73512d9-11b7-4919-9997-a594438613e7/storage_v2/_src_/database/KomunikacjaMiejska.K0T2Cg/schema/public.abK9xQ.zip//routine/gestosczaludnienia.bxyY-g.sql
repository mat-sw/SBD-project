create function gestosczaludnienia() returns trigger
    language plpgsql
as
$$
BEGIN
	UPDATE miasta SET gestosc_zaludnienia = liczba_mieszkancow / powierzchnia;
	RETURN NEW;
END;
$$;

alter function gestosczaludnienia() owner to postgres;

