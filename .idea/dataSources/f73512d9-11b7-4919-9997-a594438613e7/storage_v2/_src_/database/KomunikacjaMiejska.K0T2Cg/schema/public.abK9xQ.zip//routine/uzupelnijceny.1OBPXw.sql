create function uzupelnijceny() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.czy_ulgowy LIKE 'tak' THEN
         IF czas_przejazdu LIKE '15' THEN
             UPDATE bilety SET cena = 2;
         ELSIF czas_przejazdu LIKE '30' THEN
             UPDATE bilety SET cena = 3;
         ELSE
             UPDATE bilety SET cena = 4;
         END IF;
	ELSE
		IF czas_przejazdu LIKE '15' THEN
			 UPDATE bilety SET cena = 4;
		ELSIF czas_przejazdu LIKE '30' THEN
			UPDATE bilety SET cena = 6;
		ELSE
			UPDATE bilety SET cena = 8;
		END IF;
	END IF;
	IF strefa_typ_strefy LIKE 'B' THEN
		 UPDATE bilety SET cena = cena + 0.5;
	ELSIF strefa_typ_strefy LIKE 'C' THEN
		 UPDATE bilety SET cena = cena + 0.6;
	ELSIF strefa_typ_strefy LIKE 'AB' THEN
		 UPDATE bilety SET cena = cena + 0.7;
	ELSIF strefa_typ_strefy LIKE 'ABC' THEN
		 UPDATE bilety SET cena = cena + 1;
	END IF;
	RETURN NEW;
END;
$$;

alter function uzupelnijceny() owner to postgres;

