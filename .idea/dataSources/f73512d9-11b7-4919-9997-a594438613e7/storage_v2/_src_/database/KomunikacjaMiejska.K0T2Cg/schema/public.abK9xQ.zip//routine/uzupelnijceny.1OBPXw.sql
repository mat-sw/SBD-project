create function uzupelnijceny() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.czy_ulgowy = 'tak'::t_n THEN
         IF NEW.czas_przejazdu = '15'::type_czas_przejazdu THEN
             NEW.cena := 2;
         ELSIF NEW.czas_przejazdu = '30'::type_czas_przejazdu THEN
             UPDATE bilety SET cena = 3;
         ELSE
             UPDATE bilety SET cena = 4;
         END IF;
 	ELSE
 		IF NEW.czas_przejazdu = '15'::type_czas_przejazdu THEN
 			 UPDATE bilety SET cena = 4;
 		ELSIF NEW.czas_przejazdu = '30'::type_czas_przejazdu THEN
 			UPDATE bilety SET cena = 6;
 		ELSE
 			UPDATE bilety SET cena = 8;
 		END IF;
	END IF;
	IF NEW.strefa_typ_strefy = 'B'::type_typ_strefy THEN
		 UPDATE bilety SET cena = cena + 0.5;
	ELSIF NEW.strefa_typ_strefy = 'C'::type_typ_strefy THEN
		 UPDATE bilety SET cena = cena + 0.6;
	ELSIF NEW.strefa_typ_strefy = 'AB'::type_typ_strefy THEN
		 UPDATE bilety SET cena = cena + 0.7;
	ELSIF NEW.strefa_typ_strefy = 'ABC'::type_typ_strefy THEN
		 UPDATE bilety SET cena = cena + 1;
	END IF;
	RETURN NEW;
END;
$$;

alter function uzupelnijceny() owner to postgres;

